#include"Box/Box.h"
//#include"Box/Box.cpp"

#include"BoxList/BoxList.h"
//#include"BoxList/BoxList.cpp"

int main(){
    BoxList TaskC("txts/example.txt");
    TaskC.printList();
}